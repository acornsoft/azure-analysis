# ADR Toolkit - Project Configuration

This project uses the ADR (Architecture Decision Records) Toolkit for generating professional documentation with Accenture branding and Ecolab client specifications.

## Quick Start

### Generate DOCX from Markdown
```powershell
# From project root
.\.adr-toolkit\Convert-ToAccentureDocx.ps1 -InputFile "path\to\your\document.md"
```

### Generate ADR from Template
```powershell
# Generate new ADR
.\.adr-toolkit\Generate-Partner-ADR.ps1 -Partner Accenture -Client Ecolab -Type adf -Title "Your Title"
```

## Project Configuration

- **Partner**: Accenture
- **Client**: Ecolab
- **Default Type**: Azure Data Factory (adf)
- **Output Formats**: DOCX, PDF, HTML
- **Branding**: Accenture corporate standards with Ecolab compliance requirements

## File Structure

```
.adr-toolkit/
├── config.json              # Project configuration
├── Generate-ADR.ps1         # ADR generation script
├── Generate-Partner-ADR.ps1 # Partner-specific ADR generation
├── Convert-ToAccentureDocx.ps1 # Quick DOCX conversion
├── clients/ecolab/          # Ecolab-specific configurations
├── partners/accenture/      # Accenture templates and styles
└── types/                   # ADR type templates
```

## Usage in VS Code Co-Pilot Chat

### Standard Commands

**Convert current file to Accenture DOCX:**
```
Convert the current markdown file to Accenture-branded DOCX using the project adr-toolkit
```

**Generate new ADR:**
```
Generate a new ADR for [topic] using Accenture/Ecolab configuration
```

**Update existing ADR:**
```
Update the ADR in Analysis folder with latest content and regenerate DOCX
```

### Automation Setup

The toolkit is configured for:
- Automatic TOC generation
- Image embedding
- Accenture reference styling
- Ecolab compliance sections
- Professional formatting

## Configuration Files

- `config.json`: Project-specific settings
- `clients/ecolab/config.json`: Ecolab requirements
- `partners/accenture/config.json`: Accenture standards

## Maintenance

To update toolkit:
```powershell
# Pull latest from source
Copy-Item "src\azure-analysis\src\adr-toolkit\*" ".adr-toolkit\" -Recurse -Force
```

## Support

For issues with ADR generation or formatting, reference:
- ADR-DOCX-Template-Guide.md
- ADR-Management-SOP-Accenture.docx