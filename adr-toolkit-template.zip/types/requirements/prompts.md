# Requirements Analysis Prompts

## Description Section
**Goal**: Explain the requirement in plain English that business stakeholders can understand.

**Prompts**:
- What is the current state of the system/feature?
- What problem are we trying to solve or what opportunity are we pursuing?
- Who will benefit from this change and how?
- What is the expected business impact?

**Tips**: Keep it to 2 paragraphs. Avoid technical jargon. Focus on business value.

## User Story Section
**Goal**: Define the primary user need in the standard "As a... I want... So that..." format.

**Prompts**:
- Who is the primary user/role that will use this feature?
- What specific capability do they need?
- What business value or benefit will they achieve?

**Tips**: Focus on one primary user story. Keep it concise and outcome-focused.

## Scenarios Section
**Goal**: Describe the main use cases and edge cases using Given-When-Then format.

**Prompts**:
- What is the happy path scenario?
- What alternative paths exist?
- What error conditions should be handled?
- What edge cases need consideration?

**Tips**: Start with the primary success scenario, then add alternatives and error cases.

## Acceptance Criteria Section

### Functional Requirements
**Goal**: Define measurable requirements that prove the feature works correctly.

**Prompts**:
- What must the system do? (not how)
- How will we measure success?
- What data validation is required?
- What business rules must be enforced?

**Tips**: Make criteria measurable and testable. Focus on "what" not "how".

### Non-Functional Requirements
**Goal**: Define quality attributes like performance, security, and reliability.

**Prompts**:
- What performance standards must be met?
- What security/compliance requirements apply?
- What availability/reliability standards are needed?
- What scalability requirements exist?

**Tips**: Be specific with numbers where possible (e.g., "response time < 2 seconds").

## Technical Detail Section
**Goal**: Provide implementation guidance while maintaining separation from business requirements.

**Prompts**:
- What is the high-level implementation approach?
- What systems/components are involved?
- What are the key technical considerations?
- What dependencies and risks exist?

**Tips**: Keep this section focused on HOW while the earlier sections focus on WHAT.

## Azure-Specific Guidance

### Azure Data Factory Requirements
**User Story Focus**:
- Data engineers, analysts, system administrators
- Data integration, ETL processes, data pipeline automation
- Business intelligence, reporting, operational efficiency

**Functional Requirements Prompts**:
- What data sources and destinations are involved?
- What data transformations or business rules must be applied?
- How should data quality issues be handled?
- What are the data volume and frequency requirements?

**Non-Functional Requirements Prompts**:
- What pipeline execution time limits apply?
- What data accuracy and completeness standards are required?
- How should the solution scale with data growth?
- What monitoring and alerting is needed?

**Scenarios to Consider**:
- Successful data pipeline execution
- Data quality validation failures
- Source system unavailability
- Target system capacity issues

### Azure Functions Requirements
**User Story Focus**:
- Application developers, system integrators, API consumers
- Event-driven processing, API endpoints, automated workflows
- Real-time responses, system integration, microservices

**Functional Requirements Prompts**:
- What triggers or events should initiate processing?
- What inputs and outputs are expected?
- How should errors and exceptions be handled?
- What integration points with other systems exist?

**Non-Functional Requirements Prompts**:
- What response time and throughput requirements apply?
- How should the function scale under load?
- What cold start performance is acceptable?
- What reliability and error rates are required?

**Scenarios to Consider**:
- Successful event processing and response
- Invalid input data handling
- External service failures
- High concurrency situations

## General Guidance

### When to Use Requirements Analysis
- New feature development
- System enhancements
- Integration requirements
- Process improvements
- API/service requirements

### Best Practices
- **Collaborate**: Involve business and technical stakeholders
- **Iterate**: Start simple and refine based on feedback
- **Validate**: Ensure acceptance criteria are measurable
- **Prioritize**: Focus on high-value requirements first
- **Document**: Keep related documents and references current

### Common Pitfalls to Avoid
- Mixing WHAT with HOW in acceptance criteria
- Making requirements too technical for business stakeholders
- Creating unmeasurable acceptance criteria
- Forgetting edge cases and error scenarios
- Not considering non-functional requirements

### Validation Checklist
- [ ] Description is clear to business stakeholders
- [ ] User Story follows standard format
- [ ] Scenarios cover main paths and edge cases
- [ ] Acceptance criteria are measurable
- [ ] Technical details are separated from requirements
- [ ] Dependencies and risks are identified

## User Story Point Estimation Guidelines

### Story Point Scale Definition
**Story Point 1 (2-6 hours)**: Simple, well-understood tasks
- Straightforward implementation with clear requirements
- Minimal complexity and dependencies
- Can be completed by one developer in a short timeframe
- Low risk of complications or unknowns

**Story Point 2 (4-10 hours)**: Moderate complexity tasks
- Requires some analysis and design work
- May involve integration with existing systems
- Moderate testing requirements
- Some uncertainty but generally well-understood

**Story Point 5 (12-25 hours)**: Complex, high-effort tasks
- Significant analysis, design, and implementation work
- High complexity or multiple dependencies
- Extensive testing requirements (unit, integration, performance)
- High uncertainty or architectural impact
- May require coordination across multiple teams

### Story Point Estimation Process

**Step 1: Understand the Work**
- Read the user story and acceptance criteria carefully
- Identify all tasks required to complete the work
- Consider dependencies, testing, and documentation needs

**Step 2: Assess Complexity Factors**
- **Technical Complexity**: New technologies, algorithms, or architectural changes
- **Integration Complexity**: Number of systems or APIs involved
- **Data Complexity**: Data volume, transformation requirements, or validation needs
- **Testing Complexity**: Unit tests, integration tests, performance tests required
- **Business Logic Complexity**: Complex business rules or edge cases

**Step 3: Consider Risk and Uncertainty**
- **Known Unknowns**: Requirements that need clarification
- **Unknown Unknowns**: Potential issues not yet identified
- **External Dependencies**: Reliance on other teams or external systems
- **Learning Curve**: New skills or technologies required

**Step 4: Apply Fibonacci Scale**
- Use 1, 2, 5, 8, 13 (avoid 3, 4, 6, 7 for consistency)
- Compare to reference stories of similar complexity
- Consider team velocity and historical data
- Round up when in doubt (it's better to overestimate than underestimate)

### Story Pointing Best Practices

**Do's**:
- **Relative Estimation**: Compare complexity to previously completed stories
- **Team Consensus**: Discuss and agree as a team
- **Break Down Large Stories**: Split stories larger than 13 points
- **Consider All Aspects**: Include analysis, development, testing, and documentation
- **Re-estimate When Needed**: Update estimates as more information becomes available

**Don'ts**:
- **Don't Estimate in Hours**: Story points represent relative complexity, not time
- **Don't Consider Individual Productivity**: Base estimates on team capability
- **Don't Include Dependencies**: Focus on the story itself, not external factors
- **Don't Pad Estimates**: Be honest about complexity and risk
- **Don't Rush Estimation**: Take time to understand requirements thoroughly

### Common Story Pointing Patterns

**Story Point 1 Examples**:
- Add a new configuration parameter
- Update documentation or comments
- Simple validation rule changes
- Basic logging enhancements
- UI text or label changes

**Story Point 2 Examples**:
- Add new API endpoint with basic CRUD operations
- Implement data validation with multiple rules
- Create monitoring alerts and dashboards
- Database schema changes with migration scripts
- Integration with single external system

**Story Point 5 Examples**:
- Implement complex business logic with multiple workflows
- Major architectural changes or refactoring
- Multi-system integration with transaction management
- Performance optimization across multiple components
- Security implementation with encryption and compliance

### Story Point Calibration

**Team Velocity Calculation**:
- Track actual hours spent on completed stories
- Calculate average hours per story point
- Adjust future estimates based on actual velocity
- Reassess calibration quarterly or after significant changes

**Reference Story Creation**:
- Document completed stories as reference points
- Include actual effort, complexity factors, and lessons learned
- Use references for consistent future estimations
- Update references as team experience grows

### Azure-Specific Story Point Considerations

**Azure Data Factory**:
- **SP 1**: Simple data copy or single transformation
- **SP 2**: Multi-table ETL with error handling
- **SP 5**: Complex data pipelines with custom activities, event-driven triggers, or advanced monitoring

**Azure Functions**:
- **SP 1**: Basic HTTP trigger with simple processing
- **SP 2**: Service Bus integration with error handling
- **SP 5**: Complex event processing with multiple bindings, durable functions, or advanced retry logic

**Integration Complexity Multipliers**:
- **+1 SP**: Single external API integration
- **+2 SP**: Multiple API integrations or complex authentication
- **+3 SP**: Real-time streaming or high-throughput requirements

### Story Point Validation Checklist
- [ ] Story complexity fits within defined point ranges
- [ ] All acceptance criteria are considered in estimate
- [ ] Technical complexity is properly assessed
- [ ] Testing requirements are included
- [ ] Team consensus achieved on final estimate
- [ ] Story can be completed within 2-3 sprints if > 8 points