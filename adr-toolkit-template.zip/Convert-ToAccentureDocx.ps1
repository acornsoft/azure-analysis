param(
    [Parameter(Mandatory=$true)]
    [string]$InputFile,

    [Parameter(Mandatory=$false)]
    [string]$OutputFile,

    [Parameter(Mandatory=$false)]
    [switch]$OpenAfterConversion
)

# Get the toolkit directory
$toolkitDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Set default output file if not specified
if (-not $OutputFile) {
    $inputFileName = [System.IO.Path]::GetFileNameWithoutExtension($InputFile)
    $OutputFile = "$inputFileName-Accenture.docx"
}

# Ensure output path is absolute
if (-not [System.IO.Path]::IsPathRooted($OutputFile)) {
    $OutputFile = Join-Path (Get-Location) $OutputFile
}

# Ensure input path is absolute
if (-not [System.IO.Path]::IsPathRooted($InputFile)) {
    $InputFile = Join-Path (Get-Location) $InputFile
}

# Check if input file exists
if (-not (Test-Path $InputFile)) {
    Write-Error "Input file not found: $InputFile"
    exit 1
}

# Reference document path
$referenceDoc = Join-Path $toolkitDir "ADR-Management-SOP-Accenture.docx"

if (-not (Test-Path $referenceDoc)) {
    Write-Error "Accenture reference document not found: $referenceDoc"
    exit 1
}

Write-Host "Converting $InputFile to $OutputFile using Accenture branding..." -ForegroundColor Cyan

# Run pandoc conversion
$pandocArgs = @(
    $InputFile,
    "-o", $OutputFile,
    "--reference-doc=$referenceDoc",
    "--toc",
    "--toc-depth=3"
)

& pandoc $pandocArgs

if ($LASTEXITCODE -eq 0) {
    Write-Host "Successfully converted to: $OutputFile" -ForegroundColor Green

    # Get file info
    $fileInfo = Get-Item $OutputFile
    Write-Host "File size: $([math]::Round($fileInfo.Length / 1KB, 1)) KB" -ForegroundColor Blue

    # Open file if requested
    if ($OpenAfterConversion) {
        Start-Process $OutputFile
    }
} else {
    Write-Error "Conversion failed"
    exit 1
}