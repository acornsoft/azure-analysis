# ADR Toolkit - VS Code Co-Pilot Chat Integration

## Overview

The ADR Toolkit is now configured as a standard tool in your VS Code environment for generating professional Accenture-branded documentation. This setup ensures consistent formatting, branding, and compliance across all your projects.

## Quick Commands for Co-Pilot Chat

### Convert Current File to Accenture DOCX
```
Convert this markdown file to Accenture-branded DOCX using the project adr-toolkit
```
**What it does:**
- Takes the current open markdown file
- Converts it to DOCX with Accenture branding
- Embeds images and generates table of contents
- Opens the result automatically

### Generate New ADR
```
Generate a new ADR for [topic] using Accenture/Ecolab configuration
```
**What it does:**
- Creates a new ADR with proper structure
- Applies Accenture templates and Ecolab requirements
- Generates in all formats (DOCX, PDF, HTML)
- Includes compliance and regulatory sections

### Update Existing ADR
```
Update the ADR in Analysis folder with latest content and regenerate DOCX
```
**What it does:**
- Finds ADR files in the Analysis folder
- Regenerates documentation with latest content
- Maintains all branding and formatting

## VS Code Integration

### Tasks (Ctrl+Shift+P → "Tasks: Run Task")

1. **Convert to Accenture DOCX** - Convert current file
2. **Generate ADR** - Create new ADR with prompts
3. **Update ADR DOCX** - Refresh existing documentation

### Command Line (Terminal)

```bash
# Convert file
adr convert "Analysis\MyDocument.md"

# Generate ADR
adr generate "My ADR Title"

# Help
adr help
```

## Configuration

### Project Settings
- **Partner**: Accenture (corporate branding)
- **Client**: Ecolab (compliance requirements)
- **Default Type**: Azure Data Factory (adf)
- **Output Location**: `Analysis/Partner/Accenture/`

### File Structure
```
.adr-toolkit/           # Toolkit configuration
├── config.json         # Project settings
├── Convert-ToAccentureDocx.ps1  # Quick conversion
├── Generate-Partner-ADR.ps1     # Full ADR generation
└── README.md           # Documentation

.vscode/                # VS Code integration
├── tasks.json          # Build tasks
└── settings.json       # Editor settings

adr.bat                 # Command-line helper
```

## Standard Operating Procedure

### For New Documents
1. Write content in markdown
2. Use Co-Pilot: "Convert this to Accenture DOCX"
3. File is generated with proper branding

### For ADR Updates
1. Edit markdown source
2. Use Co-Pilot: "Update the ADR DOCX"
3. Documentation refreshes automatically

### For New ADRs
1. Use Co-Pilot: "Generate ADR for [topic]"
2. Fill in prompted information
3. Professional ADR is created

## Benefits

- **Consistency**: All documents follow Accenture standards
- **Compliance**: Ecolab regulatory requirements included
- **Efficiency**: One-command conversion
- **Quality**: Professional formatting and branding
- **Automation**: Integrated into development workflow

## Troubleshooting

### Images Not Showing
- Ensure images are in same directory as markdown file
- Check file paths in markdown (should be relative)

### Conversion Fails
- Verify pandoc is installed
- Check file permissions
- Ensure reference document exists

### VS Code Tasks Not Available
- Reload VS Code window (Ctrl+Shift+P → "Developer: Reload Window")
- Check .vscode/tasks.json exists

## Maintenance

The toolkit is configured to:
- Update automatically when source templates change
- Maintain backward compatibility
- Support new ADR types and formats
- Include latest compliance requirements

For questions or issues, reference the toolkit documentation in `.adr-toolkit/README.md`.